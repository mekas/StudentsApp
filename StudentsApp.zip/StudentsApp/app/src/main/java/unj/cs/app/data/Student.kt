package unj.cs.app.data

class Student{
    var id:String
    var name:String
    constructor(id:String, name:String){
        this.id = id
        this.name = name
    }
}