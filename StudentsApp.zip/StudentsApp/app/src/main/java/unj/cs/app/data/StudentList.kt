package unj.cs.app.data

object StudentList {
    var list = mutableListOf<Student>()
}
