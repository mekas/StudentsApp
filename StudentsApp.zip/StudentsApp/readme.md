# Starting branch
This branch contain initial project template for StudentApp. You can start working from this project.
